<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{srchidx}prestashop>srchidx_2595fac9115a538e0f165fca45892f14'] = 'Indexador de búsquedas';
$_MODULE['<{srchidx}prestashop>srchidx_e081771a6ac331b57201f012029a644c'] = 'Reconstruye el índice de búsqueda secuencialmente para evitar timeouts.';
$_MODULE['<{srchidx}prestashop>config_5234806162309ca9e0465f98c2b0daf8'] = 'Reconstruír índice de búsqueda';
$_MODULE['<{srchidx}prestashop>config_6433f0a69ae010c1676ccbd33fdcaef0'] = 'Iniciar';
$_MODULE['<{srchidx}prestashop>config_a6d87940b0bb5ed9023bb057635b6509'] = 'Obteniendo índices';
$_MODULE['<{srchidx}prestashop>config_0412b552da0f7f390175e0f42a194b7a'] = 'Obteniendo palabras';
$_MODULE['<{srchidx}prestashop>config_46458717a0a0a75b2fbd54d5060409dc'] = 'Obteniendo productos';
$_MODULE['<{srchidx}prestashop>config_0a4f4925e048a7082f2af7d005c87033'] = 'Limpiando índices';
$_MODULE['<{srchidx}prestashop>config_f7c293936e65f9b8f765680a0584ed92'] = 'Limpiando palabras';
$_MODULE['<{srchidx}prestashop>config_521d4edc7c22d5f63bc5912ff2afa61a'] = 'Indexando';
$_MODULE['<{srchidx}prestashop>config_56fb5905b11e72c7fcf903134b1def87'] = 'Finalizado!';
$_MODULE['<{srchidx}prestashop>config_902b0d55fddef6f8d651fe1035b7d4bd'] = 'Error';
